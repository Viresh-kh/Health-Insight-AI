import React, { useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  User 
} from 'firebase/auth';
import { 
  collection, 
  query, 
  orderBy, 
  onSnapshot, 
  addDoc, 
  serverTimestamp,
  doc,
  setDoc,
  getDoc
} from 'firebase/firestore';
import { Toaster, toast } from 'sonner';
import { auth, db } from './firebase';
import { getDocFromServer } from 'firebase/firestore';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  Activity, 
  History as HistoryIcon, 
  PlusCircle, 
  LogOut, 
  Stethoscope, 
  AlertTriangle, 
  CheckCircle2, 
  Info,
  ChevronRight,
  User as UserIcon,
  Loader2,
  Settings,
  TrendingUp,
  Lightbulb,
  X,
  Heart,
  MessageSquare,
  Send,
  Calendar,
  Clock,
  Video,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { cn } from './lib/utils';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

// --- Types ---
interface HealthLog {
  id: string;
  userId: string;
  symptoms: string;
  analysis: string;
  timestamp: any;
  severity: 'low' | 'medium' | 'high' | 'emergency';
}

interface Appointment {
  id: string;
  userId: string;
  doctorName: string;
  specialty: string;
  date: string;
  time: string;
  type: 'virtual' | 'in-person';
  status: 'scheduled' | 'completed' | 'cancelled';
  createdAt: any;
}

interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  age?: number;
  gender?: string;
  conditions?: string;
}

// --- Error Boundary ---
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean, error: any }> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-red-50 p-6">
          <div className="max-w-md w-full bg-white p-8 rounded-2xl shadow-xl border border-red-100 text-center space-y-4">
            <AlertTriangle className="w-12 h-12 text-red-500 mx-auto" />
            <h2 className="text-xl font-bold text-slate-900">Something went wrong</h2>
            <p className="text-slate-500 text-sm">We encountered an unexpected error. Please try refreshing the page.</p>
            <Button onClick={() => window.location.reload()} className="w-full">Refresh App</Button>
            {process.env.NODE_ENV !== 'production' && (
              <pre className="text-[10px] text-left bg-slate-50 p-4 rounded overflow-auto max-h-40">
                {this.state.error?.message}
              </pre>
            )}
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- AI Service ---
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function analyzeSymptoms(symptoms: string, profile?: UserProfile) {
  const profileContext = profile ? `
    User Profile Context:
    - Age: ${profile.age || 'Not provided'}
    - Gender: ${profile.gender || 'Not provided'}
    - Pre-existing Conditions: ${profile.conditions || 'None provided'}
  ` : '';

  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: `Analyze the following symptoms and provide a structured health recommendation. 
    ${profileContext}
    Symptoms: ${symptoms}
    
    Provide the response in Markdown format with the following sections:
    1. **Possible Conditions**: List likely causes.
    2. **Severity Assessment**: Categorize as Low, Medium, High, or Emergency.
    3. **Recommendations**: Immediate steps to take.
    4. **When to see a doctor**: Specific red flags.
    
    Disclaimer: This is an AI-generated assessment and not a professional medical diagnosis.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          analysis: { type: Type.STRING, description: "The full markdown analysis" },
          severity: { type: Type.STRING, enum: ["low", "medium", "high", "emergency"] }
        },
        required: ["analysis", "severity"]
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (e) {
    console.error("Failed to parse AI response:", response.text);
    // Fallback if JSON parsing fails
    return {
      analysis: response.text || "Failed to generate analysis. Please try again.",
      severity: "medium"
    };
  }
}

async function getDailyInsight() {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: "Provide a short, encouraging, and scientifically accurate daily health tip or insight (max 150 characters).",
  });
  return response.text;
}

// --- Error Handling ---
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  toast.error(`Database error: ${errInfo.error}`);
}

// --- Components ---

const Button = ({ className, variant = 'primary', ...props }: any) => {
  const variants = {
    primary: "bg-emerald-600 text-white hover:bg-emerald-700",
    secondary: "bg-white text-slate-900 border border-slate-200 hover:bg-slate-50",
    ghost: "bg-transparent text-slate-600 hover:bg-slate-100",
    danger: "bg-red-50 text-red-600 hover:bg-red-100"
  };
  return (
    <button 
      className={cn("px-4 py-2 rounded-lg font-medium transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2", variants[variant as keyof typeof variants], className)} 
      {...props} 
    />
  );
};

const Card = ({ children, className }: any) => (
  <div className={cn("bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden", className)}>
    {children}
  </div>
);

export default function App() {
  return (
    <ErrorBoundary>
      <Toaster position="top-center" richColors />
      <MainApp />
    </ErrorBoundary>
  );
}

function MainApp() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [logs, setLogs] = useState<HealthLog[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [view, setView] = useState<'checker' | 'history' | 'profile' | 'appointments'>('checker');
  const [input, setInput] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [loggingIn, setLoggingIn] = useState(false);
  const [currentResult, setCurrentResult] = useState<{ analysis: string, severity: string } | null>(null);
  const [dailyInsight, setDailyInsight] = useState<string>('');
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };
  const [feedbackType, setFeedbackType] = useState<'bug' | 'suggestion' | 'other'>('suggestion');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [sendingFeedback, setSendingFeedback] = useState(false);
  const [booking, setBooking] = useState(false);

  useEffect(() => {
    // Fetch daily insight
    getDailyInsight().then(setDailyInsight).catch(err => console.error("Failed to fetch insight:", err));

    // Test Connection
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('offline')) {
          console.error("Firebase connection test failed: client is offline.");
        }
      }
    };
    testConnection();

    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        // Sync user profile
        const userRef = doc(db, 'users', u.uid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          const newProfile = {
            uid: u.uid,
            email: u.email!,
            displayName: u.displayName!,
            photoURL: u.photoURL!,
            createdAt: serverTimestamp()
          };
          await setDoc(userRef, newProfile);
          setProfile(newProfile as any);
        } else {
          setProfile(userSnap.data() as UserProfile);
        }

        // Listen for logs
        const q = query(collection(db, 'users', u.uid, 'logs'), orderBy('timestamp', 'desc'));
        const unsubLogs = onSnapshot(q, (snapshot) => {
          const l = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as HealthLog));
          setLogs(l);
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${u.uid}/logs`);
        });

        // Listen for appointments
        const qApps = query(collection(db, 'users', u.uid, 'appointments'), orderBy('date', 'asc'));
        const unsubApps = onSnapshot(qApps, (snapshot) => {
          const a = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Appointment));
          setAppointments(a);
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${u.uid}/appointments`);
        });

        return () => {
          unsubLogs();
          unsubApps();
        };
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleUpdateProfile = async (data: Partial<UserProfile>) => {
    if (!user) return;
    const userRef = doc(db, 'users', user.uid);
    try {
      await setDoc(userRef, data, { merge: true });
      setProfile(prev => prev ? { ...prev, ...data } : null);
      toast.success('Profile updated successfully');
      setView('checker');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  const handleLogin = async () => {
    if (loggingIn) return;
    setLoggingIn(true);
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      if (error.code === 'auth/cancelled-popup-request' || error.code === 'auth/popup-closed-by-user') {
        console.log("Login cancelled or interrupted.");
      } else {
        console.error("Login failed:", error);
        toast.error('Login failed. Please try again.');
      }
    } finally {
      setLoggingIn(false);
    }
  };

  const handleLogout = () => signOut(auth);

  const handleSendFeedback = async () => {
    if (!user || !feedbackMessage.trim()) return;
    setSendingFeedback(true);
    try {
      await addDoc(collection(db, 'feedback'), {
        userId: user.uid,
        userEmail: user.email,
        message: feedbackMessage,
        type: feedbackType,
        timestamp: serverTimestamp()
      });
      toast.success('Feedback sent! Thank you for helping us improve.');
      setIsFeedbackOpen(false);
      setFeedbackMessage('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'feedback');
    } finally {
      setSendingFeedback(false);
    }
  };

  const handleBookAppointment = async (data: { doctorName: string, specialty: string, date: string, time: string }) => {
    if (!user) return;
    setBooking(true);
    try {
      await addDoc(collection(db, `users/${user.uid}/appointments`), {
        userId: user.uid,
        ...data,
        type: 'virtual',
        status: 'scheduled',
        createdAt: serverTimestamp()
      });
      toast.success(`Appointment booked with ${data.doctorName}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/appointments`);
    } finally {
      setBooking(false);
    }
  };

  const handleAnalyze = async () => {
    if (!input.trim() || !user) return;
    setAnalyzing(true);
    setCurrentResult(null); // Clear previous result
    try {
      const result = await analyzeSymptoms(input, profile || undefined);
      setCurrentResult(result);
      
      // Save to Firestore
      await addDoc(collection(db, 'users', user.uid, 'logs'), {
        userId: user.uid,
        symptoms: input,
        analysis: result.analysis,
        severity: result.severity,
        timestamp: serverTimestamp()
      });
      toast.success('Analysis complete!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/logs`);
    } finally {
      setAnalyzing(false);
    }
  };

  const severityToValue = (s: string) => {
    switch(s) {
      case 'emergency': return 4;
      case 'high': return 3;
      case 'medium': return 2;
      case 'low': return 1;
      default: return 0;
    }
  };

  const chartData = [...logs].reverse().map(log => ({
    date: log.timestamp?.toDate().toLocaleDateString([], { month: 'short', day: 'numeric' }),
    severity: severityToValue(log.severity),
    rawSeverity: log.severity
  }));

  if (loading && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full text-center space-y-8"
        >
          <div className="flex justify-center">
            <div className="w-20 h-20 bg-emerald-100 rounded-3xl flex items-center justify-center">
              <Stethoscope className="w-10 h-10 text-emerald-600" />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-bold tracking-tight text-slate-900">HealthCheck AI</h1>
            <p className="text-slate-500 text-lg">Your intelligent companion for symptom analysis and health guidance.</p>
          </div>
          <Button onClick={handleLogin} disabled={loggingIn} className="w-full py-4 text-lg">
            {loggingIn ? <Loader2 className="w-6 h-6 animate-spin" /> : "Get Started with Google"}
          </Button>
          <p className="text-xs text-slate-400">
            By continuing, you acknowledge that this tool is for informational purposes only and not a substitute for professional medical advice.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-emerald-600 text-xl">
            <Activity className="w-6 h-6" />
            <span>HealthCheck AI</span>
          </div>
          <div className="flex items-center gap-4">
            <nav className="hidden md:flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <button 
                onClick={() => setView('checker')}
                className={cn("px-4 py-1.5 rounded-lg text-sm font-medium transition-all", view === 'checker' ? "bg-white shadow-sm text-emerald-600" : "text-slate-500 hover:text-slate-700")}
              >
                Checker
              </button>
              <button 
                onClick={() => setView('appointments')}
                className={cn("px-4 py-1.5 rounded-lg text-sm font-medium transition-all", view === 'appointments' ? "bg-white shadow-sm text-emerald-600" : "text-slate-500 hover:text-slate-700")}
              >
                Book
              </button>
              <button 
                onClick={() => setView('history')}
                className={cn("px-4 py-1.5 rounded-lg text-sm font-medium transition-all", view === 'history' ? "bg-white shadow-sm text-emerald-600" : "text-slate-500 hover:text-slate-700")}
              >
                History
              </button>
              <button 
                onClick={() => setView('profile')}
                className={cn("px-4 py-1.5 rounded-lg text-sm font-medium transition-all", view === 'profile' ? "bg-white shadow-sm text-emerald-600" : "text-slate-500 hover:text-slate-700")}
              >
                Profile
              </button>
            </nav>
            <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-semibold text-slate-900">{user.displayName}</p>
                <button onClick={handleLogout} className="text-[10px] text-slate-400 hover:text-red-500 uppercase tracking-wider font-bold">Logout</button>
              </div>
              <img src={user.photoURL || ''} alt="" className="w-8 h-8 rounded-full border border-slate-200" referrerPolicy="no-referrer" />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {view === 'checker' ? (
            <motion.div 
              key="checker"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-8"
            >
              <div className="max-w-2xl mx-auto space-y-6">
                {dailyInsight && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-gradient-to-br from-emerald-500 to-teal-600 p-6 rounded-3xl text-white shadow-lg shadow-emerald-200/50 relative overflow-hidden group"
                  >
                    <div className="relative z-10 flex items-start gap-4">
                      <div className="bg-white/20 p-2 rounded-xl backdrop-blur-sm">
                        <Lightbulb className="w-6 h-6" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-bold uppercase tracking-widest opacity-80">Daily Health Insight</p>
                        <p className="text-lg font-medium leading-tight">{dailyInsight}</p>
                      </div>
                    </div>
                    <Heart className="absolute -bottom-4 -right-4 w-24 h-24 opacity-10 group-hover:scale-110 transition-transform duration-500" />
                  </motion.div>
                )}

                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">How are you feeling today?</h2>
                  <p className="text-slate-500">Describe your symptoms in detail for a more accurate assessment.</p>
                </div>
                
                <Card className="p-4 focus-within:ring-2 ring-emerald-500/20 transition-all">
                  <textarea 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="e.g., I have a persistent dry cough, mild fever, and fatigue for the last 3 days..."
                    className="w-full h-40 resize-none border-none focus:ring-0 text-lg placeholder:text-slate-300"
                  />
                  <div className="flex justify-between items-center mt-4 pt-4 border-t border-slate-100">
                    <div className="flex items-center gap-2 text-slate-400 text-xs">
                      <Info className="w-4 h-4" />
                      <span>Be as specific as possible</span>
                    </div>
                    <Button 
                      onClick={handleAnalyze} 
                      disabled={!input.trim() || analyzing}
                      className="min-w-[140px]"
                    >
                      {analyzing ? <Loader2 className="w-5 h-5 animate-spin" /> : "Analyze Symptoms"}
                    </Button>
                  </div>
                </Card>

                {currentResult && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div className={cn(
                      "p-4 rounded-2xl flex items-center gap-4",
                      currentResult.severity === 'emergency' ? "bg-red-50 text-red-700 border border-red-100" :
                      currentResult.severity === 'high' ? "bg-orange-50 text-orange-700 border border-orange-100" :
                      currentResult.severity === 'medium' ? "bg-yellow-50 text-yellow-700 border border-yellow-100" :
                      "bg-emerald-50 text-emerald-700 border border-emerald-100"
                    )}>
                      <AlertTriangle className="w-6 h-6 shrink-0" />
                      <div>
                        <p className="font-bold uppercase text-xs tracking-widest">Severity Assessment</p>
                        <p className="text-lg font-semibold capitalize">{currentResult.severity}</p>
                      </div>
                    </div>

                    <Card className="p-8 prose prose-slate max-w-none">
                      <Markdown>{currentResult.analysis}</Markdown>
                    </Card>

                    <div className="bg-slate-100 p-4 rounded-xl text-xs text-slate-500 text-center italic">
                      Disclaimer: This assessment is for informational purposes only. If you are experiencing a medical emergency, call your local emergency services immediately.
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          ) : view === 'history' ? (
            <motion.div 
              key="history"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Your Health History</h2>
                <Button variant="secondary" onClick={() => setView('checker')} className="text-sm">
                  <PlusCircle className="w-4 h-4" />
                  New Check
                </Button>
              </div>

              {logs.length > 0 && (
                <Card className="p-6 space-y-4">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-emerald-600" />
                    <h3 className="font-bold">Severity Trends</h3>
                  </div>
                  <div className="h-[200px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData}>
                        <defs>
                          <linearGradient id="colorSeverity" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
                        <YAxis hide domain={[0, 4]} />
                        <Tooltip 
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              return (
                                <div className="bg-white p-2 border border-slate-200 rounded-lg shadow-xl text-[10px]">
                                  <p className="font-bold text-slate-900">{payload[0].payload.date}</p>
                                  <p className="text-emerald-600 uppercase font-bold">{payload[0].payload.rawSeverity}</p>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Area type="monotone" dataKey="severity" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorSeverity)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </Card>
              )}

              {logs.length === 0 ? (
                <div className="text-center py-20 space-y-4">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto">
                    <HistoryIcon className="w-8 h-8 text-slate-300" />
                  </div>
                  <p className="text-slate-500">No previous checks found.</p>
                </div>
              ) : (
                <div className="grid gap-4">
                  {logs.map((log) => (
                    <Card key={log.id} className="hover:border-emerald-200 transition-colors cursor-pointer group">
                      <div className="p-6 flex items-start justify-between gap-4">
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center gap-3">
                            <span className={cn(
                              "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider",
                              log.severity === 'emergency' ? "bg-red-100 text-red-700" :
                              log.severity === 'high' ? "bg-orange-100 text-orange-700" :
                              log.severity === 'medium' ? "bg-yellow-100 text-yellow-700" :
                              "bg-emerald-100 text-emerald-700"
                            )}>
                              {log.severity}
                            </span>
                            <span className="text-xs text-slate-400">
                              {log.timestamp?.toDate().toLocaleDateString()} at {log.timestamp?.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <h3 className="font-semibold text-lg line-clamp-1">{log.symptoms}</h3>
                        </div>
                        <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-emerald-500 transition-colors" />
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div 
              key="profile"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="max-w-xl mx-auto"
            >
              <Card className="p-8 space-y-8">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center">
                    <UserIcon className="w-8 h-8 text-emerald-600" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold">Health Profile</h2>
                    <p className="text-slate-500 text-sm">Help AI provide more accurate assessments.</p>
                  </div>
                </div>

                <form className="space-y-6" onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  handleUpdateProfile({
                    age: Number(formData.get('age')),
                    gender: formData.get('gender') as string,
                    conditions: formData.get('conditions') as string
                  });
                }}>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Age</label>
                      <input 
                        name="age"
                        type="number" 
                        defaultValue={profile?.age}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 ring-emerald-500/20 outline-none"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Gender</label>
                      <select 
                        name="gender"
                        defaultValue={profile?.gender}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 ring-emerald-500/20 outline-none"
                      >
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                        <option value="prefer-not-to-say">Prefer not to say</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Pre-existing Conditions</label>
                    <textarea 
                      name="conditions"
                      defaultValue={profile?.conditions}
                      placeholder="e.g., Asthma, Type 2 Diabetes, Hypertension..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 ring-emerald-500/20 outline-none h-32 resize-none"
                    />
                  </div>

                  <div className="flex gap-3">
                    <Button type="submit" className="flex-1">Save Profile</Button>
                    <Button type="button" variant="secondary" onClick={() => setView('checker')}>Cancel</Button>
                  </div>
                </form>

                <div className="pt-8 border-t border-slate-100 space-y-4">
                  {deferredPrompt && (
                    <div className="bg-emerald-600 p-6 rounded-2xl flex items-center justify-between gap-4 text-white">
                      <div>
                        <h3 className="font-bold">Install App</h3>
                        <p className="text-white/80 text-sm">Add icon to your home screen.</p>
                      </div>
                      <Button variant="secondary" onClick={handleInstallClick} className="bg-white text-emerald-600 hover:bg-emerald-50 border-none">
                        <Download className="w-4 h-4" />
                        Install Now
                      </Button>
                    </div>
                  )}

                  <div className="bg-slate-50 p-6 rounded-2xl flex items-center justify-between gap-4">
                    <div>
                      <h3 className="font-bold">Have feedback?</h3>
                      <p className="text-slate-500 text-sm">Help us improve HealthCheck AI.</p>
                    </div>
                    <Button variant="secondary" onClick={() => setIsFeedbackOpen(true)}>
                      <MessageSquare className="w-4 h-4" />
                      Send Feedback
                    </Button>
                  </div>
                </div>
              </Card>
            </motion.div>
          )}

          {view === 'appointments' && (
            <motion.div 
              key="appointments"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 space-y-6">
                  <Card className="p-6">
                    <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-emerald-600" />
                      Book Consultation
                    </h3>
                    <form onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      handleBookAppointment({
                        doctorName: formData.get('doctor') as string,
                        specialty: formData.get('specialty') as string,
                        date: formData.get('date') as string,
                        time: formData.get('time') as string,
                      });
                      (e.target as HTMLFormElement).reset();
                    }} className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-400 uppercase">Doctor</label>
                        <select name="doctor" required className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 outline-none">
                          <option value="Dr. Sarah Smith">Dr. Sarah Smith</option>
                          <option value="Dr. James Wilson">Dr. James Wilson</option>
                          <option value="Dr. Elena Rodriguez">Dr. Elena Rodriguez</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-400 uppercase">Specialty</label>
                        <input name="specialty" required placeholder="e.g. Cardiology" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 outline-none" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-400 uppercase">Date</label>
                        <input type="date" name="date" required className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 outline-none" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-400 uppercase">Time</label>
                        <input type="time" name="time" required className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 outline-none" />
                      </div>
                      <Button className="w-full py-3 mt-4" disabled={booking}>
                        <motion.div
                          initial={false}
                          animate={{ scale: booking ? 0.95 : 1 }}
                          className="flex items-center gap-2"
                        >
                          {booking ? <Loader2 className="w-5 h-5 animate-spin" /> : "Book Now"}
                        </motion.div>
                      </Button>
                    </form>
                  </Card>
                </div>

                <div className="lg:col-span-2 space-y-6">
                  <h3 className="text-xl font-bold flex items-center gap-2">
                    <Clock className="w-5 h-5 text-emerald-600" />
                    Upcoming Appointments
                  </h3>
                  {appointments.length === 0 ? (
                    <Card className="p-12 text-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Calendar className="w-8 h-8 text-slate-300" />
                      </div>
                      <p className="text-slate-500">No appointments scheduled yet.</p>
                    </Card>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {appointments.map((app) => (
                        <Card key={app.id} className="p-6 hover:shadow-lg transition-shadow">
                          <div className="flex items-start justify-between">
                            <div className="flex gap-4">
                              <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center shrink-0">
                                <Video className="w-6 h-6 text-emerald-600" />
                              </div>
                              <div>
                                <h4 className="font-bold text-lg">{app.doctorName}</h4>
                                <p className="text-slate-500 text-sm">{app.specialty}</p>
                                <div className="flex items-center gap-4 mt-3">
                                  <div className="flex items-center gap-1.5 text-slate-600 text-sm">
                                    <Calendar className="w-4 h-4" />
                                    {app.date}
                                  </div>
                                  <div className="flex items-center gap-1.5 text-slate-600 text-sm">
                                    <Clock className="w-4 h-4" />
                                    {app.time}
                                  </div>
                                </div>
                              </div>
                            </div>
                            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold uppercase tracking-wider">
                              {app.status}
                            </span>
                          </div>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Feedback Modal */}
        <AnimatePresence>
          {isFeedbackOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsFeedbackOpen(false)}
                className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden"
              >
                <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="text-xl font-bold">Send Feedback</h3>
                  <button onClick={() => setIsFeedbackOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                    <X className="w-5 h-5 text-slate-400" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Feedback Type</label>
                    <div className="flex gap-2">
                      {(['suggestion', 'bug', 'other'] as const).map((t) => (
                        <button
                          key={t}
                          onClick={() => setFeedbackType(t)}
                          className={cn(
                            "flex-1 py-2 px-3 rounded-xl text-sm font-medium border transition-all capitalize",
                            feedbackType === t 
                              ? "bg-emerald-50 border-emerald-200 text-emerald-700" 
                              : "bg-white border-slate-200 text-slate-500 hover:border-slate-300"
                          )}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Message</label>
                    <textarea 
                      value={feedbackMessage}
                      onChange={(e) => setFeedbackMessage(e.target.value)}
                      placeholder="What's on your mind?"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 ring-emerald-500/20 outline-none h-32 resize-none"
                    />
                  </div>
                  <Button 
                    className="w-full py-4" 
                    onClick={handleSendFeedback}
                    disabled={sendingFeedback || !feedbackMessage.trim()}
                  >
                    {sendingFeedback ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Submit Feedback
                      </>
                    )}
                  </Button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* Mobile Nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-2 pb-safe pt-2 flex items-center justify-around z-50">
        <button 
          onClick={() => setView('checker')}
          className={cn(
            "flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition-all", 
            view === 'checker' ? "text-emerald-600" : "text-slate-400"
          )}
        >
          <Activity className={cn("w-6 h-6", view === 'checker' && "animate-pulse")} />
          <span className="text-[10px] font-bold uppercase tracking-wider">Check</span>
        </button>
        <button 
          onClick={() => setView('appointments')}
          className={cn(
            "flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition-all", 
            view === 'appointments' ? "text-emerald-600" : "text-slate-400"
          )}
        >
          <Calendar className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase tracking-wider">Book</span>
        </button>
        <button 
          onClick={() => setView('history')}
          className={cn(
            "flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition-all", 
            view === 'history' ? "text-emerald-600" : "text-slate-400"
          )}
        >
          <HistoryIcon className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase tracking-wider">History</span>
        </button>
        <button 
          onClick={() => setView('profile')}
          className={cn(
            "flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition-all", 
            view === 'profile' ? "text-emerald-600" : "text-slate-400"
          )}
        >
          <UserIcon className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase tracking-wider">Profile</span>
        </button>
      </div>
    </div>
  );
}
